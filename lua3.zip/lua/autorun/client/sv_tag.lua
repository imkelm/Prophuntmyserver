// Server Side
// Originally Made By: TyGuy
// Edited By: CaptainDeagle62
AddCSLuaFile( "cl_chat_tags.lua"  )