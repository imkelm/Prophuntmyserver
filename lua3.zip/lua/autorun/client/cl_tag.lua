// Client Side
// Originally Made By: TyGuy
// Edited By: CaptainDeagle62

local Tags = 
{
--Group    --Tag     --Color
{"admin", "Admin", Color(0, 0, 255, 255) },
{"superadmin", "SuperAdmin", Color(255, 0, 0, 255) },
{"owner", "Owner", Color(0, 255, 0, 255) },
{"moderator", "Moderator", Color(100, 100, 0, 200) },
{"respected", "Respected", Color(75,100,255,0) },
}

hook.Add("OnPlayerChat", "Tags", function(ply, Text, Team, PlayerIsDead)
	if ply:IsValid() then
		for k,v in pairs(Tags) do
			if ply:IsUserGroup(v[1]) then
				if Team then
						if ply:Alive() then
							chat.AddText(Color(0, 204, 0, 255), "{TEAM} ", v[3], v[2], Color(50, 50, 50, 255), "| ", v[3], ply:Nick(), color_white, ": ", Color(255, 255, 255, 255), Text)
						else
							chat.AddText(Color(255, 0, 0, 255), "*DEAD*", Color(0, 204, 0, 255), "{TEAM} ", v[3], v[2], Color(50, 50, 50, 255), "| ", v[3], ply:Nick(), color_white, ": ", Color(255, 255, 255, 255), Text)
						end
						return true
				end
				if ply:IsPlayer() then
					if ply:Alive() then
						chat.AddText(Color(255, 0, 0, 255), "", v[3], v[2], Color(50, 50, 50, 255), "| ", v[3], ply:Nick(), color_white, ": ", Color(255, 255, 255, 255), Text)
						return true
					elseif !ply:Alive() then
						chat.AddText(Color(255, 0, 0, 255), "*Dead* ", v[3], v[2], Color(50, 50, 50, 255), "| ", v[3], ply:Nick(), color_white, ": ", Color(255, 255, 255, 255), Text)
						return true
					end
				end
			end
		end
	end
end)